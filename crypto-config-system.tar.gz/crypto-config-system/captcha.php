<?php
require_once 'includes/Captcha.php';

$captcha = new Captcha();
$captcha->generate();